import copy, hashlib, json, math, struct
from pathlib import Path

source = Path('/tmp/venuepilot-village-hall.glb')
out = Path('/tmp/venuepilot-village-hall-single-room.glb')
raw = source.read_bytes()
magic, version, size = struct.unpack_from('<III', raw, 0)
assert magic == 0x46546c67 and version == 2 and size == len(raw)
chunks=[]; off=12
while off<len(raw):
    length, kind=struct.unpack_from('<II',raw,off); chunks.append((kind, raw[off+8:off+8+length])); off+=8+length
original=json.loads(next(data for kind,data in chunks if kind==0x4e4f534a))
binary=next(data for kind,data in chunks if kind==0x004e4942)
assert not any(original.get(k) for k in ['animations','skins','images','textures'])
# Source group numbers: preserve the main room as authored, without reseating chairs.
chair_numbers = set(range(84,90)) | set(range(91,97)) | set(range(102,111))
keep_numbers = set(range(0,25)) | set(range(35,45)) | set(range(47,52)) | set(range(57,65)) | set(range(67,71)) | set(range(72,82)) | chair_numbers
nodes=original['nodes']; original_roots=nodes[0]['children']
number=lambda idx:int(nodes[idx]['name'].split('-',1)[0])
retained_roots=[idx for idx in original_roots if number(idx) in keep_numbers]
removed_roots=[idx for idx in original_roots if number(idx) not in keep_numbers]
reachable={0}
def visit(idx):
    reachable.add(idx)
    for child in nodes[idx].get('children',[]):visit(child)
for idx in retained_roots:visit(idx)
node_order=sorted(reachable); node_map={old:new for new,old in enumerate(node_order)}
mesh_order=sorted({nodes[i]['mesh'] for i in node_order if 'mesh' in nodes[i]}); mesh_map={old:new for new,old in enumerate(mesh_order)}
material_order=sorted({p['material'] for i in mesh_order for p in original['meshes'][i]['primitives'] if 'material' in p}); material_map={old:new for new,old in enumerate(material_order)}
accessor_usage={}
for m in mesh_order:
    for p in original['meshes'][m]['primitives']:
        if 'indices' in p:accessor_usage[p['indices']]=34963
        for a in p.get('attributes',{}).values():accessor_usage[a]=34962
        for target in p.get('targets',[]):
            for a in target.values():accessor_usage[a]=34962
accessor_order=sorted(accessor_usage); accessor_map={old:new for new,old in enumerate(accessor_order)}
component_bytes={5120:1,5121:1,5122:2,5123:2,5125:4,5126:4}
components={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT2':4,'MAT3':9,'MAT4':16}
new_accessors=[];new_views=[];new_binary=bytearray()
def accessor_values(a_idx, doc=original, blob=binary):
    a=doc['accessors'][a_idx]; assert 'sparse' not in a
    v=doc['bufferViews'][a['bufferView']]
    elem=component_bytes[a['componentType']]*components[a['type']]
    stride=v.get('byteStride',elem)
    start=v.get('byteOffset',0)+a.get('byteOffset',0)
    return [blob[start+i*stride:start+i*stride+elem] for i in range(a['count'])],elem
for old in accessor_order:
    a=copy.deepcopy(original['accessors'][old]); records,elem=accessor_values(old)
    while len(new_binary)%4:new_binary.append(0)
    start=len(new_binary)
    stride=((elem+3)//4)*4 if accessor_usage[old]==34962 else elem
    for record in records:new_binary.extend(record);new_binary.extend(b'\0'*(stride-elem))
    v={'buffer':0,'byteOffset':start,'byteLength':len(new_binary)-start,'target':accessor_usage[old]}
    if accessor_usage[old]==34962:v['byteStride']=stride
    a['bufferView']=len(new_views);a.pop('byteOffset',None)
    new_views.append(v);new_accessors.append(a)
result={k:copy.deepcopy(v) for k,v in original.items() if k not in ['nodes','meshes','materials','accessors','bufferViews','buffers','scenes','scene']}
result['nodes']=[]
chair_records=[]
for old in node_order:
    n=copy.deepcopy(nodes[old])
    if old==0:n['children']=retained_roots
    if 'children' in n:n['children']=[node_map[c] for c in n['children']]
    if 'mesh' in n:n['mesh']=mesh_map[n['mesh']]
    if old in retained_roots and number(old) in chair_numbers:
        n.setdefault('extras',{})['venuePilot']={'wholeChairId':n['name'],'sourceNodeIndex':old}
        chair_records.append({'wholeChairId':n['name'],'sourceNodeIndex':old,'outputNodeIndex':node_map[old],'sourceChildNodeIndices':nodes[old]['children'],'outputChildNodeIndices':n['children'],'translation':nodes[old].get('translation',[0,0,0]),'rotationQuaternionXYZW':nodes[old].get('rotation',[0,0,0,1]),'scale':nodes[old].get('scale',[1,1,1])})
    result['nodes'].append(n)
result['meshes']=[]
for old in mesh_order:
    m=copy.deepcopy(original['meshes'][old])
    for p in m['primitives']:
        if 'indices' in p:p['indices']=accessor_map[p['indices']]
        p['attributes']={k:accessor_map[v] for k,v in p['attributes'].items()}
        if 'material' in p:p['material']=material_map[p['material']]
        for target in p.get('targets',[]):
            for k,v in list(target.items()):target[k]=accessor_map[v]
    result['meshes'].append(m)
result['materials']=[copy.deepcopy(original['materials'][i]) for i in material_order]
result['accessors']=new_accessors;result['bufferViews']=new_views;result['buffers']=[{'byteLength':len(new_binary)}]
result['scenes']=[{'name':'Village Hall - Main Room Only','nodes':[0]}];result['scene']=0
result['asset'].setdefault('extras',{})['venuePilotPreparation']={'source':'https://cdn.3dassets.dev/assets/35232/v1/model.glb','sourcePage':'https://3dassets.dev/packs/village-hall-and-community-events','license':'CC0-1.0','sourceUsesAI':True,'sourceSha256':hashlib.sha256(raw).hexdigest(),'preparation':'Retain existing main-hall shell, stage and 21 independently movable whole-chair groups; remove kitchen/side floor strip and event clutter. No new geometry and no transforms changed.'}
json_chunk=json.dumps(result,separators=(',',':'),ensure_ascii=True).encode()
json_chunk+=b' '*((-len(json_chunk))%4)
bin_chunk=bytes(new_binary)+b'\0'*((-len(new_binary))%4)
total=12+8+len(json_chunk)+8+len(bin_chunk)
out.write_bytes(struct.pack('<III',0x46546c67,2,total)+struct.pack('<II',len(json_chunk),0x4e4f534a)+json_chunk+struct.pack('<II',len(bin_chunk),0x004e4942)+bin_chunk)
# Confirm every retained accessor's decoded raw components are byte-identical.
for old in accessor_order:
    before,_=accessor_values(old)
    after,_=accessor_values(accessor_map[old],result,bytes(new_binary))
    assert before==after, old
# Confirm retained node transforms and chair descendants were not altered.
for old in node_order:
    for key in ['matrix','translation','rotation','scale']:
        assert nodes[old].get(key)==result['nodes'][node_map[old]].get(key),(old,key)
for c in chair_records:
    assert len(c['sourceChildNodeIndices'])==2
assert len(chair_records)==21
report={'source':str(source),'prepared':str(out),'sourceBytes':len(raw),'preparedBytes':out.stat().st_size,'sourceSha256':hashlib.sha256(raw).hexdigest(),'preparedSha256':hashlib.sha256(out.read_bytes()).hexdigest(),'axes':{'up':'+Y','distanceUnits':'meters','localChairForward':'+Z (the unrotated chair back is toward -Z)','stageAt':'negative Z end; chairs retain original event/table-facing rotations'},'license':'CC0-1.0','sourcePage':'https://3dassets.dev/packs/village-hall-and-community-events','sourceUsesAI':True,'keptRootGroups':[{'sourceNodeIndex':i,'outputNodeIndex':node_map[i],'name':nodes[i]['name'],'translation':nodes[i].get('translation',[0,0,0])} for i in retained_roots],'removedRootGroups':[{'sourceNodeIndex':i,'name':nodes[i]['name'],'translation':nodes[i].get('translation',[0,0,0])} for i in removed_roots],'wholeChairs':chair_records,'wholeChairSourceNodeIndices':[c['sourceNodeIndex'] for c in chair_records],'wholeChairOutputNodeIndices':[c['outputNodeIndex'] for c in chair_records],'validation':{'retainedGeometryAccessorDataByteIdentical':True,'retainedNodeTransformsUnchanged':True,'wholeChairCount':len(chair_records),'allWholeChairsHaveFrameAndSeatBackChildMeshes':True,'allUnusedNodesAndMeshesRemoved':True,'sourceNodeCount':len(nodes),'preparedNodeCount':len(result['nodes']),'sourceMeshCount':len(original['meshes']),'preparedMeshCount':len(result['meshes'])},'limitations':['Prepared cutaway main hall, preserving the original partial wall shell. No new walls or platforms added.','Original chairs remain in event/table-facing positions; removed tables leave a non-row seating arrangement.','The existing serving-hatch wall module is retained as part of the main-hall boundary; no kitchen geometry remains behind it.','No wheelchair bays, routes, collisions, or sightlines have been audited.','Two fused chair stacks and the linked six-chair row were removed; only independently movable whole-chair groups remain.']}
Path('/tmp/venuepilot-village-hall-extraction.json').write_text(json.dumps(report,indent=2))
Path('/tmp/venuepilot-village-hall-single-room.gltf.json').write_text(json.dumps(result,indent=2))
print(json.dumps({'prepared':str(out),'bytes':out.stat().st_size,'nodes':len(result['nodes']),'meshes':len(result['meshes']),'keptRootGroups':len(retained_roots),'removedRootGroups':len(removed_roots),'wholeChairs':len(chair_records),'chairNodeIndices':report['wholeChairOutputNodeIndices'],'validation':report['validation']},indent=2))
