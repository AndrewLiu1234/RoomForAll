# Village Hall — single room

Prepared single-room seating study from an existing downloadable scene. License: CC0 1.0.

## What is included

21 complete stacking chairs in one flat main hall, with a stage and presentation furniture. The kitchen, side wing, tables, event stalls, chair stacks and fused linked-chair row have been removed. Original chair positions and rotations are preserved; some still face where event tables originally stood. This is a starting arrangement for your system to reorganize. The original cutaway wall shell and boundary serving hatch remain; no kitchen geometry is included.

- `scene.glb`: the prepared model, 638,412 bytes.
- `seats.json`: the exact complete-chair parent IDs, indices and original transforms.
- `PREPARATION.json`: source identity, original-to-prepared mappings, cleanup and validation.
- `preview.png`: an actual render of this prepared file with neutral test lighting.
- `prepare_source.py`: reproducible preparation script; its default /tmp input/output paths can be changed for your machine.

## How to use

Load `scene.glb` with a glTF 2.0 loader. Select a seat by `seats.json` -> `movableSeats` -> `nodeName`. Translate or rotate that entire parent; the seat, back, legs and attached parts move together. Treat other geometry as fixed until explicitly annotated. The asset is in meters with +Y up. Source GLB rotation values are quaternion XYZW, not degrees.

Both files were loaded and rendered in Three.js. A representative chair was translated 0.2 m along X: all its parts moved together and every other object stayed fixed, then the original transform was restored. Graph checks confirmed that the seat groups contain complete, nonoverlapping component sets.

This package supplies geometry and object identity. Your team still needs to annotate the usable floor, allowed seat-movement regions, stage/board target, attendee eye offsets and body proxies, occupied wheelchair bays and routes, then run the view/access evaluator. No accessibility or visibility improvement has been claimed or scored. The prepared scene uses a flat floor.

## Provenance

- Author/source: 3DAssets.dev (publisher identifies the source as AI-generated).
- Source page: https://3dassets.dev/packs/village-hall-and-community-events
- Untouched source download: https://cdn.3dassets.dev/assets/35232/v1/model.glb
- License: https://creativecommons.org/publicdomain/zero/1.0/

The source download contains areas removed from this prepared file; use the included `scene.glb` for the focused study. No building or chair geometry was generated from scratch. All retained chair geometry and original chair world transforms were preserved.
